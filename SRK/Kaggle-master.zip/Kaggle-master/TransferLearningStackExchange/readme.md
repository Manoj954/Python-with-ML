Codes for the Kaggle competition - Transfer Learning on Stack Exchange Tags is present here.
