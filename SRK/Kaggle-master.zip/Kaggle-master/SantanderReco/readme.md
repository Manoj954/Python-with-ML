Codes for Kaggle competition - [Santander Product recommendation](https://www.kaggle.com/c/santander-product-recommendation) is present in this folder.
