This folder has the codes which I have used in the Kaggle - [Liberty Mutual Competition](http://www.kaggle.com/c/liberty-mutual-fire-peril)

prepareData.py - File used to do data preprocessing and then to create features from the given raw file

finalModel.py - Module used to train the final model and to make predictions 
