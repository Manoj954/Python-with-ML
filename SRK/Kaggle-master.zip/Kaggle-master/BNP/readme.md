Code for Kaggle - BNP competition where we finished in 12th position
