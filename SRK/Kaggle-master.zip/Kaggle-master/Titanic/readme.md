Codes for the titanic competition
