Codes for the Kaggle - Spooky Author challenge 
