Ipython notebooks created for exploring the [Indian Premier League dataset](https://www.kaggle.com/manasgarg/ipl) present in Kaggle is present in this folder.

File explanations:

 1. IPL_Exploration.ipynb - Notebook which has some exploratory analysis on the IPL data
 2. IPL_Win_Prediction.ipynb - Notebook to predict the win probability of the given team at the end of each over
