Codes for the [Kaggle Expedia Competition](https://www.kaggle.com/c/expedia-hotel-recommendations)
