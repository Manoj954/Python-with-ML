1. splitDevVal.py - Code to split the train data into dev and val samples based on time
2. getBookings.py - Code to get the bookings from the train file
3. getClicks.py - Code to get the clicks from train file
4. splitDevVal_Bookings.py - Code to split the bookings into dev and val sample based on time
5. splitDevVal_Clicks.py - Code to split the clicks into dev and val sample based on time
6. getLeakRows_val.py - Code to get the leaky rows of validation sample and save it in csv file
7. getLeakRows_test.py - Code to get the leaky rows of test sample and save it in csv file 
8. getLeakFree.py - Code to get the leak free rows for both test and val sample
