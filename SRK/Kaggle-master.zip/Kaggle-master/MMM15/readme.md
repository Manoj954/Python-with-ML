This folder has the codes for [Kaggle Competition](http://www.kaggle.com/competitions) - [March Machine Learning Mania 2015](http://www.kaggle.com/c/march-machine-learning-mania-2015)
