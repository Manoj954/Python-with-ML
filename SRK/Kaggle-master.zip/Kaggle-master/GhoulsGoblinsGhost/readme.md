Codes for the Kaggle competition - [Ghouls, Goblins and Ghosts](https://www.kaggle.com/c/ghouls-goblins-and-ghosts-boo/) are present in this folder

1. [Kaggle kernel for exploration](https://www.kaggle.com/sudalairajkumar/ghouls-goblins-and-ghosts-boo/simple-exploration-notebook)
