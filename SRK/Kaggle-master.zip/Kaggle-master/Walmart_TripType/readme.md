This folder has the codes used for competition Kaggle - [Walmart - Trip Type Classification](https://www.kaggle.com/c/walmart-recruiting-trip-type-classification)

Finished 23rd out of >1000 people in this competition

Approach:
 1. Built few XGB models by converting the features to sparse format and the best model is present in XGB folder
 2. Built few Neural Net models using Keras using features excluding UPCs and the best model is present in neuralnets folder
 3. My final model is an ensemble of XGBs and NNs
