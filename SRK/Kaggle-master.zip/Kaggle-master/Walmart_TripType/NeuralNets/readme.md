Codes for best Neural Net model
