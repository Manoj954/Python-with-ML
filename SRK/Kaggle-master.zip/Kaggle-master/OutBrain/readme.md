Codes for the Kaggle competition - [Outbrain Click Prediction](https://www.kaggle.com/c/outbrain-click-prediction)
